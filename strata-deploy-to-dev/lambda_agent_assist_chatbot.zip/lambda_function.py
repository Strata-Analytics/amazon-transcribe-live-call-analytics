import boto3
import json
import os
from boto3.dynamodb.conditions import Key

bedrock = boto3.client('bedrock-runtime', region_name='us-east-1')
bedrock_agent = boto3.client('bedrock-agent-runtime', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

DYNAMODB_TABLE_NAME = os.environ.get('DYNAMODB_TABLE_NAME', '')
KNOWLEDGE_BASE_ID = os.environ.get('KNOWLEDGE_BASE_ID', '')
MAX_CONTEXT_SEGMENTS = 20  # More context for the chat bot

SYSTEM_PROMPT = """Eres el asistente inteligente de un agente de contact center de telecomunicaciones de TelcoStrata.

Tu rol es responder preguntas del agente humano durante una llamada activa, basándote en la transcripción de la conversación y los catálogos de productos disponibles.

REGLAS:
- Responde en texto natural, claro y directo. No uses JSON.
- Máximo 4 oraciones por respuesta, a menos que se pida un resumen o script largo.
- Usa español latinoamericano neutro.
- Usa nombres y precios exactos del catálogo: MOV-BASIC $199, MOV-PLUS $299, MOV-PRO $449, MOV-UNLIMITED $599, HOG-50 $349, HOG-100 $499, HOG-300 $699, HOG-GIGA $999.
- NUNCA uses placeholders como [PLAN_SUPERIOR] o [PRECIO]. Siempre usa el valor real.
- Si no hay suficiente información en la transcripción para responder con certeza, dilo claramente.
- Dirígete al agente directamente, como si fuera un colega: "Te sugiero...", "El cliente mencionó...", "Puedes ofrecerle...".

CAPACIDADES:
- Resumir la llamada hasta el momento actual
- Identificar el tema principal y la intención del cliente
- Sugerir scripts específicos para la situación actual
- Calcular ahorros y comparar planes del catálogo
- Recomendar la siguiente mejor acción con argumentos concretos
- Generar frases de cierre o manejo de objeciones adaptadas al contexto"""


def get_call_context(dynamodb_pk: str, table_name: str = '') -> str:
    """Lee el historial completo de la llamada desde DynamoDB."""
    name = table_name or DYNAMODB_TABLE_NAME
    if not name or not dynamodb_pk:
        return ""
    try:
        table = dynamodb.Table(name)
        response = table.query(
            KeyConditionExpression=Key('PK').eq(dynamodb_pk),
            ScanIndexForward=True,  # Chronological order for the bot
            Limit=MAX_CONTEXT_SEGMENTS * 2
        )
        segments = []
        for item in response.get('Items', []):
            if item.get('Channel') in ('CALLER', 'AGENT') and item.get('Transcript'):
                role = 'Cliente' if item['Channel'] == 'CALLER' else 'Agente'
                sentiment = item.get('Sentiment', '')
                sentiment_str = f" [{sentiment}]" if sentiment and sentiment not in ('NEUTRAL', '') else ''
                segments.append(f"{role}{sentiment_str}: {item['Transcript']}")
        return '\n'.join(segments)
    except Exception as e:
        print(f"Error reading DynamoDB context: {e}")
        return ""


def query_knowledge_base(query: str) -> str:
    """Consulta la Bedrock Knowledge Base."""
    if not KNOWLEDGE_BASE_ID:
        return ""
    try:
        response = bedrock_agent.retrieve(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            retrievalQuery={'text': query},
            retrievalConfiguration={
                'vectorSearchConfiguration': {'numberOfResults': 5}  # More results for the bot
            }
        )
        results = []
        for result in response.get('retrievalResults', []):
            content = result.get('content', {}).get('text', '')
            if content:
                results.append(content)
        return '\n\n'.join(results)
    except Exception as e:
        print(f"Error querying KB: {e}")
        return ""


# Predefined prompts for quick action buttons
BUTTON_PROMPTS = {
    "SUMMARIZE_CURRENT_CALL": "Basándote en la transcripción, escribe un resumen de máximo 3 puntos sobre: el motivo de la llamada, lo que se ha discutido, y el estado actual. Dirígete al agente directamente.",
    "IDENTIFY_CURRENT_TOPIC": "¿Cuál es el tema principal que está tratando el cliente ahora mismo? Responde en una sola oración e incluye la intención detectada (cancelar, comprar, quejarse, consultar, etc.).",
    "SUGGEST_RETENTION_SCRIPT": "El cliente parece querer cancelar o está insatisfecho. Basándote en la conversación y el catálogo, sugiere al agente exactamente qué decir ahora para retener al cliente. Incluye la oferta específica con precio real.",
    "SUGGEST_UPSELL_SCRIPT": "Basándote en la conversación, sugiere al agente exactamente qué decir para hacer un upsell o cross-sell en este momento. Incluye el nombre del plan, precio y beneficio principal.",
    "SUGGEST_CLOSING_SCRIPT": "El cliente parece receptivo. Sugiere al agente una frase de cierre concreta y natural para este momento específico de la conversación.",
}


def lambda_handler(event, context):
    print("Event:", json.dumps(event))

    # Input from the frontend panel
    # Expected fields:
    #   call_id: str — current call ID
    #   message: str — agent's question or button action
    #   button_action: str (optional) — one of BUTTON_PROMPTS keys
    #   dynamodb_pk: str (optional) — DynamoDB partition key
    #   dynamodb_table_name: str (optional) — table name override

    # API Gateway HTTP wraps the body as a string — parse it
    if 'body' in event:
        try:
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        except (json.JSONDecodeError, TypeError):
            body = {}
    else:
        body = event

    call_id = body.get('call_id', body.get('callId', ''))
    agent_message = body.get('message', body.get('text', '')).strip()
    button_action = body.get('button_action', '')
    dynamodb_pk = body.get('dynamodb_pk', f'trs#{call_id}')
    table_name = body.get('dynamodb_table_name', DYNAMODB_TABLE_NAME)

    # Resolve what the agent is asking
    if button_action and button_action in BUTTON_PROMPTS:
        user_query = BUTTON_PROMPTS[button_action]
    elif agent_message:
        user_query = agent_message
    else:
        return build_response("No recibí ninguna pregunta. Por favor escribe algo o selecciona una acción.")

    # Get full call transcript from DynamoDB
    call_transcript = get_call_context(dynamodb_pk, table_name)

    # Query KB with the agent's question
    kb_context = query_knowledge_base(user_query)

    # Build the prompt
    parts = []

    if kb_context:
        parts.append(f"INFORMACIÓN DEL CATÁLOGO:\n{kb_context}")

    if call_transcript:
        parts.append(f"TRANSCRIPCIÓN DE LA LLAMADA HASTA AHORA:\n{call_transcript}")
    else:
        parts.append("TRANSCRIPCIÓN: No disponible aún.")

    parts.append(f"PREGUNTA DEL AGENTE:\n{user_query}")

    user_message = '\n\n'.join(parts)

    try:
        response = bedrock.invoke_model(
            modelId='us.amazon.nova-lite-v1:0',
            body=json.dumps({
                'system': [{'text': SYSTEM_PROMPT}],
                'messages': [{'role': 'user', 'content': [{'text': user_message}]}],
                'inferenceConfig': {'maxTokens': 400, 'temperature': 0.3}
            })
        )
        result = json.loads(response['body'].read())
        text = result['output']['message']['content'][0]['text'].strip()
        return build_response(text)

    except Exception as e:
        print(f"Bedrock error: {e}")
        return build_response("No pude procesar tu consulta en este momento. Intenta de nuevo.")


def build_response(message: str) -> dict:
    return {'message': message}